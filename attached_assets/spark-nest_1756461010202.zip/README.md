# Notemint — Full-stack Notes App

A modern, responsive notes app with Email + OTP and Google sign-in. Secure JWT auth, CRUD notes, TypeScript everywhere, Express API, Postgres via Prisma (Neon recommended).

## Tech
- Frontend: React + Vite + TypeScript + Tailwind
- Backend: Express + TypeScript
- Auth: Email OTP (dev in-memory), Google Sign-In (ID token), JWT
- DB: PostgreSQL via Prisma (Neon serverless recommended)

## Environment Variables
Set via your project settings or environment (prefer setting with the platform Env tool):
- JWT_SECRET: strong secret for signing JWTs
- DATABASE_URL: Postgres connection string (e.g., from Neon)
- GOOGLE_CLIENT_ID: Google OAuth Web client ID (for Google Identity Services)

## Development
- Install deps: `pnpm install --no-frozen-lockfile`
- Start: `pnpm dev` (serves SPA + API on one port)

Email OTP uses an in-memory store for development. In production, integrate an email provider and persistent OTP log.

## Database (Neon + Prisma)
1. Create a Neon Postgres database
2. Set DATABASE_URL
3. Generate client: `pnpm prisma:generate`
4. Migrate: `pnpm prisma:migrate`

Schema is in `prisma/schema.prisma`.

## API
- POST /api/auth/send-otp { email }
- POST /api/auth/verify-otp { email, otp }
- POST /api/auth/google { idToken }
- GET  /api/me (JWT)
- GET  /api/notes (JWT)
- POST /api/notes { title, content } (JWT)
- DELETE /api/notes/:id (JWT)

## Deployment
Use Netlify or Vercel via MCP integrations.
- Netlify: Connect Netlify MCP, then deploy.
- Vercel: Connect Vercel MCP, then deploy.

## Notes
- If GOOGLE_CLIENT_ID is not set, the Google button is hidden.
- If DATABASE_URL is not set, the app falls back to an in-memory store (dev only). Set DATABASE_URL to enable Postgres.
