import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

interface UserInfo {
  id: string;
  email: string;
  name?: string | null;
  avatarUrl?: string | null;
}

interface Note {
  id: string;
  title: string;
  content: string;
  createdAt: string;
}

const getToken = () => localStorage.getItem("token") || "";

export default function AppPage() {
  const nav = useNavigate();
  const [user, setUser] = useState<UserInfo | null>(null);
  const [notes, setNotes] = useState<Note[]>([]);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const authHeaders = useMemo(
    () => ({ Authorization: `Bearer ${getToken()}` }),
    []
  );

  useEffect(() => {
    const token = getToken();
    if (!token) {
      nav("/");
      return;
    }
    (async () => {
      try {
        const u = await fetch("/api/me", { headers: authHeaders }).then((r) =>
          r.ok ? r.json() : Promise.reject(r)
        );
        setUser(u);
        const ns = await fetch("/api/notes", { headers: authHeaders }).then(
          (r) => (r.ok ? r.json() : Promise.reject(r))
        );
        setNotes(ns);
      } catch (e) {
        setError("Session expired. Please sign in again.");
        localStorage.removeItem("token");
        setTimeout(() => nav("/"), 1200);
      }
    })();
  }, [nav, authHeaders]);

  const addNote = async () => {
    setError(null);
    if (!title.trim() && !content.trim()) return;
    setLoading(true);
    try {
      const n = await fetch("/api/notes", {
        method: "POST",
        headers: { "Content-Type": "application/json", ...authHeaders },
        body: JSON.stringify({ title, content }),
      }).then((r) => (r.ok ? r.json() : Promise.reject(r)));
      setNotes([n, ...notes]);
      setTitle("");
      setContent("");
    } catch (e: any) {
      setError("Failed to create note");
    } finally {
      setLoading(false);
    }
  };

  const del = async (id: string) => {
    try {
      await fetch(`/api/notes/${id}`, { method: "DELETE", headers: authHeaders });
      setNotes(notes.filter((n) => n.id !== id));
    } catch (e) {
      setError("Failed to delete note");
    }
  };

  const logout = () => {
    localStorage.removeItem("token");
    nav("/");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-pink-50">
      <header className="sticky top-0 z-10 backdrop-blur supports-[backdrop-filter]:bg-white/60 bg-white/80 border-b">
        <div className="mx-auto max-w-6xl px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-tr from-indigo-600 to-fuchsia-500" />
            <span className="font-extrabold tracking-tight text-xl">Notemint</span>
          </div>
          <div className="flex items-center gap-4">
            {user && (
              <div className="flex items-center gap-3">
                {user.avatarUrl ? (
                  <img src={user.avatarUrl} alt="avatar" className="h-8 w-8 rounded-full" />
                ) : (
                  <div className="h-8 w-8 rounded-full bg-indigo-200" />
                )}
                <div className="text-sm leading-tight">
                  <div className="font-semibold">{user.name || user.email}</div>
                  <div className="text-gray-500">{user.email}</div>
                </div>
              </div>
            )}
            <button onClick={logout} className="px-3 py-2 rounded-md bg-gray-900 text-white hover:bg-black transition">Log out</button>
          </div>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-8 grid md:grid-cols-3 gap-6">
        <section className="md:col-span-1">
          <div className="rounded-2xl border bg-white shadow-sm p-5">
            <h2 className="text-lg font-semibold mb-3">Create a note</h2>
            <input
              className="w-full rounded-md border px-3 py-2 mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <textarea
              className="w-full rounded-md border px-3 py-2 h-32 mb-3 resize-none focus:outline-none focus:ring-2 focus:ring-indigo-500"
              placeholder="Write your thoughts..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            <button disabled={loading} onClick={addNote} className="w-full rounded-md bg-gradient-to-r from-indigo-600 to-fuchsia-600 text-white py-2 font-semibold shadow hover:opacity-95 disabled:opacity-60">
              {loading ? "Adding..." : "Add Note"}
            </button>
            {error && <p className="text-red-600 text-sm mt-3">{error}</p>}
          </div>
        </section>
        <section className="md:col-span-2">
          <div className="grid gap-4 sm:grid-cols-2">
            {notes.map((n) => (
              <article key={n.id} className="rounded-2xl border bg-white/90 shadow-sm p-5 relative">
                <h3 className="font-semibold text-lg mb-1">{n.title || "Untitled"}</h3>
                <p className="text-gray-600 whitespace-pre-wrap">{n.content}</p>
                <time className="text-xs text-gray-400">{new Date(n.createdAt).toLocaleString()}</time>
                <button onClick={() => del(n.id)} className="absolute top-4 right-4 text-red-600 hover:text-red-700">Delete</button>
              </article>
            ))}
            {notes.length === 0 && (
              <div className="text-gray-500">No notes yet. Create your first note!</div>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
