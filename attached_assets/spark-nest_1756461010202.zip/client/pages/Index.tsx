import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

declare global {
  interface Window {
    google?: any;
  }
}

function GoogleSignIn({ onToken, clientId }: { onToken: (t: string) => void; clientId?: string }) {
  const btnRef = useRef<HTMLDivElement | null>(null);
  useEffect(() => {
    if (!clientId) return; // hide if not configured
    const s = document.createElement("script");
    s.src = "https://accounts.google.com/gsi/client";
    s.async = true;
    s.defer = true;
    s.onload = () => {
      if (!window.google) return;
      window.google.accounts.id.initialize({
        client_id: clientId,
        callback: (resp: any) => onToken(resp.credential),
        auto_select: false,
        ux_mode: "popup",
      });
      if (btnRef.current) {
        window.google.accounts.id.renderButton(btnRef.current, {
          theme: "filled_black",
          size: "large",
          shape: "pill",
          text: "continue_with",
          width: 320,
        });
      }
    };
    document.head.appendChild(s);
    return () => {
      document.head.removeChild(s);
    };
  }, [clientId, onToken]);

  if (!clientId) return null;
  return <div ref={btnRef} />;
}

export default function Index() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [step, setStep] = useState<"email" | "otp">("email");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [devOtp, setDevOtp] = useState<string | null>(null);
  const GOOGLE_CLIENT_ID = (import.meta as any).env.VITE_GOOGLE_CLIENT_ID as string | undefined;

  const startOtp = async () => {
    setError(null);
    if (!EMAIL_RE.test(email)) return setError("Enter a valid email address");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setStep("otp");
      setDevOtp(data.devCode || null);
    } catch (e: any) {
      setError("Failed to send OTP");
    } finally {
      setLoading(false);
    }
  };

  const verify = async () => {
    setError(null);
    if (!/^\d{6}$/.test(otp)) return setError("Enter the 6-digit code");
    setLoading(true);
    try {
      const res = await fetch("/api/auth/verify-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, otp }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      localStorage.setItem("token", data.token);
      nav("/app");
    } catch (e: any) {
      setError("Incorrect code or expired OTP");
    } finally {
      setLoading(false);
    }
  };

  const onGoogle = async (idToken: string) => {
    setError(null);
    try {
      const res = await fetch("/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken }),
      });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      localStorage.setItem("token", data.token);
      nav("/app");
    } catch (e: any) {
      setError("Google sign-in failed");
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden bg-grid-slate-100">
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-100 via-white to-pink-100" />
      <div className="relative z-10">
        <header className="max-w-6xl mx-auto px-4 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-gradient-to-tr from-indigo-600 to-fuchsia-500" />
            <span className="font-extrabold tracking-tight text-xl">Notemint</span>
          </div>
          <a href="#features" className="text-sm text-gray-600 hover:text-gray-900">Features</a>
        </header>

        <main className="max-w-6xl mx-auto px-4 grid lg:grid-cols-2 gap-10 items-center py-8">
          <section>
            <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight leading-tight">
              Capture ideas instantly. Keep them beautifully organized.
            </h1>
            <p className="mt-4 text-lg text-gray-600 max-w-prose">
              Sign up with email + OTP or Google. Your notes are secured with JWT and only you can create or delete them.
            </p>
            <div className="mt-8 rounded-2xl border bg-white/80 backdrop-blur shadow p-6 max-w-md">
              {step === "email" ? (
                <div>
                  <label className="block text-sm font-medium mb-2">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full rounded-md border px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    onClick={startOtp}
                    disabled={loading}
                    className="mt-4 w-full rounded-md bg-gradient-to-r from-indigo-600 to-fuchsia-600 text-white py-2 font-semibold shadow hover:opacity-95 disabled:opacity-60"
                  >
                    {loading ? "Sending..." : "Continue with Email"}
                  </button>
                  <div className="my-4 flex items-center gap-3 text-gray-400">
                    <div className="h-px bg-gray-200 flex-1" /> or <div className="h-px bg-gray-200 flex-1" />
                  </div>
                  <GoogleSignIn onToken={onGoogle} clientId={GOOGLE_CLIENT_ID} />
                  {!GOOGLE_CLIENT_ID && (
                    <p className="text-xs text-gray-500 mt-2">Google sign-in unavailable (missing client ID)</p>
                  )}
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-medium mb-2">Enter the 6-digit code</label>
                  <input
                    inputMode="numeric"
                    pattern="[0-9]*"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                    placeholder="••••••"
                    className="w-full tracking-widest text-center text-xl rounded-md border px-3 py-3 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    onClick={verify}
                    disabled={loading}
                    className="mt-4 w-full rounded-md bg-gray-900 text-white py-2 font-semibold shadow hover:bg-black disabled:opacity-60"
                  >
                    {loading ? "Verifying..." : "Verify & Continue"}
                  </button>
                  <button className="mt-3 text-sm text-gray-600 hover:text-gray-900" onClick={() => setStep("email")}>Use a different email</button>
                  {devOtp && (
                    <p className="text-xs text-gray-500 mt-2">Dev code: {devOtp}</p>
                  )}
                </div>
              )}
              {error && <p className="text-red-600 text-sm mt-3">{error}</p>}
            </div>
          </section>
          <section className="hidden lg:block">
            <div className="relative">
              <div className="absolute -inset-6 bg-gradient-to-tr from-indigo-300/40 to-fuchsia-300/40 blur-2xl rounded-3xl" />
              <img src="/placeholder.svg" alt="Preview" className="relative rounded-3xl border shadow-xl" />
            </div>
          </section>
        </main>

        <footer className="max-w-6xl mx-auto px-4 py-10 text-sm text-gray-500">
          © {new Date().getFullYear()} Notemint
        </footer>
      </div>
    </div>
  );
}
