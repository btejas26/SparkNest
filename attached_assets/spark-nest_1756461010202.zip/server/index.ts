import "dotenv/config";
import express from "express";
import cors from "cors";
import { handleDemo } from "./routes/demo";
import authRouter from "./routes/auth";
import notesRouter from "./routes/notes";
import { authRequired, meHandler } from "./routes/middleware";

export function createServer() {
  const app = express();

  // Middleware
  app.use(cors());
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Health
  app.get("/api/ping", (_req, res) => {
    const ping = process.env.PING_MESSAGE ?? "ping";
    res.json({ message: ping });
  });

  // Demo
  app.get("/api/demo", handleDemo);

  // Auth
  app.use("/api/auth", authRouter);
  app.get("/api/me", authRequired, meHandler);

  // Notes (protected)
  app.use("/api/notes", authRequired, notesRouter);

  return app;
}
