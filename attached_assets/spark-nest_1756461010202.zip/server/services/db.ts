import crypto from "node:crypto";

export type Provider = "email" | "google";

export interface DbUser {
  id: string;
  email: string;
  name: string | null;
  avatarUrl: string | null;
  provider: Provider;
  providerId: string | null;
}

export interface DbNote {
  id: string;
  userId: string;
  title: string;
  content: string;
  createdAt: Date;
}

const hasDbUrl = !!process.env.DATABASE_URL;

let prisma: any = null;
if (hasDbUrl) {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { PrismaClient } = require("@prisma/client");
    prisma = new PrismaClient();
  } catch (e) {
    prisma = null;
  }
}

// In-memory fallback (development without DB)
const mem = {
  users: new Map<string, DbUser>(),
  notes: new Map<string, DbNote>(),
  byEmail: new Map<string, string>(),
};

async function upsertUser(u: Omit<DbUser, "id">): Promise<DbUser> {
  if (prisma) {
    const existing = await prisma.user.upsert({
      where: { email: u.email },
      update: { name: u.name, avatarUrl: u.avatarUrl, provider: u.provider, providerId: u.providerId },
      create: { email: u.email, name: u.name, avatarUrl: u.avatarUrl, provider: u.provider, providerId: u.providerId },
    });
    return { ...existing } as DbUser;
  }
  const existingId = mem.byEmail.get(u.email);
  if (existingId) {
    const existing = mem.users.get(existingId)!;
    const updated = { ...existing, ...u };
    mem.users.set(existingId, updated);
    return updated;
  }
  const id = crypto.randomUUID();
  const user: DbUser = { id, ...u };
  mem.users.set(id, user);
  mem.byEmail.set(u.email, id);
  return user;
}

async function listNotes(userId: string): Promise<DbNote[]> {
  if (prisma) {
    const ns = await prisma.note.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
    return ns as DbNote[];
  }
  return Array.from(mem.notes.values())
    .filter((n) => n.userId === userId)
    .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
}

async function createNote(userId: string, title: string, content: string): Promise<DbNote> {
  if (prisma) {
    const n = await prisma.note.create({ data: { userId, title, content } });
    return n as DbNote;
  }
  const n: DbNote = { id: crypto.randomUUID(), userId, title, content, createdAt: new Date() };
  mem.notes.set(n.id, n);
  return n;
}

async function deleteNote(userId: string, id: string): Promise<boolean> {
  if (prisma) {
    const n = await prisma.note.findUnique({ where: { id } });
    if (!n || n.userId !== userId) return false;
    await prisma.note.delete({ where: { id } });
    return true;
  }
  const n = mem.notes.get(id);
  if (!n || n.userId !== userId) return false;
  mem.notes.delete(id);
  return true;
}

export const db = { upsertUser, listNotes, createNote, deleteNote };
