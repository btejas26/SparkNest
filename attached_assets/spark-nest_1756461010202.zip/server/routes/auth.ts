import { Router, type RequestHandler } from "express";
import { signJwt, type AuthUser } from "./middleware";
import crypto from "node:crypto";

// In-memory OTP store for dev. Use a proper email/SMS provider in production.
const otpStore = new Map<string, { code: string; exp: number }>();

// DB adapter interface (implemented in db.ts)
import { db } from "../services/db";

const router = Router();

const sendOtp: RequestHandler = async (req, res) => {
  const { email } = req.body as { email?: string };
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    return res.status(400).json({ error: "Invalid email" });
  }
  const code = ("" + Math.floor(100000 + Math.random() * 900000)).slice(0, 6);
  const exp = Date.now() + 10 * 60 * 1000;
  otpStore.set(email.toLowerCase(), { code, exp });
  // TODO: send code via email provider. For dev, return code for convenience.
  res.json({ ok: true, devCode: process.env.NODE_ENV !== "production" ? code : undefined });
};

const verifyOtp: RequestHandler = async (req, res) => {
  const { email, otp } = req.body as { email?: string; otp?: string };
  const entry = email ? otpStore.get(email.toLowerCase()) : undefined;
  if (!email || !otp || !entry) return res.status(400).json({ error: "Invalid request" });
  if (Date.now() > entry.exp) return res.status(400).json({ error: "OTP expired" });
  if (entry.code !== otp) return res.status(400).json({ error: "Incorrect code" });

  // Upsert user
  const user = await db.upsertUser({
    email: email.toLowerCase(),
    name: null,
    avatarUrl: null,
    provider: "email",
    providerId: null,
  });
  const token = signJwt(user as AuthUser);
  res.json({ token, user });
};

// Google Sign-In via ID token (client obtains idToken)
const googleSignIn: RequestHandler = async (req, res) => {
  const { idToken } = req.body as { idToken?: string };
  if (!idToken) return res.status(400).json({ error: "Missing idToken" });
  try {
    // Verify with Google tokeninfo endpoint
    const resp = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${idToken}`);
    if (!resp.ok) throw new Error("tokeninfo failed");
    const data = (await resp.json()) as any;
    const audOk = process.env.GOOGLE_CLIENT_ID ? data.aud === process.env.GOOGLE_CLIENT_ID : true;
    if (!audOk) return res.status(400).json({ error: "Invalid audience" });
    const email = data.email as string;
    const name = data.name as string | undefined;
    const picture = data.picture as string | undefined;

    const user = await db.upsertUser({
      email: email.toLowerCase(),
      name: name || null,
      avatarUrl: picture || null,
      provider: "google",
      providerId: data.sub,
    });
    const token = signJwt(user as AuthUser);
    res.json({ token, user });
  } catch (e) {
    res.status(400).json({ error: "Invalid Google token" });
  }
};

router.post("/send-otp", sendOtp);
router.post("/verify-otp", verifyOtp);
router.post("/google", googleSignIn);

export default router;
