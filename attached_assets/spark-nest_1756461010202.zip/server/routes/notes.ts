import { Router, type RequestHandler } from "express";
import { db } from "../services/db";

const router = Router();

const list: RequestHandler = async (req, res) => {
  const userId = req.user!.id;
  const notes = await db.listNotes(userId);
  res.json(notes);
};

const create: RequestHandler = async (req, res) => {
  const userId = req.user!.id;
  const { title, content } = req.body as { title?: string; content?: string };
  if (!title && !content) return res.status(400).json({ error: "Title or content required" });
  const note = await db.createNote(userId, title || "", content || "");
  res.status(201).json(note);
};

const remove: RequestHandler = async (req, res) => {
  const userId = req.user!.id;
  const id = req.params.id;
  const ok = await db.deleteNote(userId, id);
  if (!ok) return res.status(404).json({ error: "Note not found" });
  res.json({ ok: true });
};

router.get("/", list);
router.post("/", create);
router.delete("/:id", remove);

export default router;
