import type { RequestHandler } from "express";
import jwt from "jsonwebtoken";

export interface AuthUser {
  id: string;
  email: string;
  name?: string | null;
  avatarUrl?: string | null;
}

declare global {
  namespace Express {
    interface Request {
      user?: AuthUser;
    }
  }
}

const JWT_SECRET = process.env.JWT_SECRET || "dev-secret-notemint";

export const signJwt = (user: AuthUser) =>
  jwt.sign({ sub: user.id, email: user.email, name: user.name, avatarUrl: user.avatarUrl }, JWT_SECRET, {
    expiresIn: "7d",
  });

export const authRequired: RequestHandler = (req, res, next) => {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Missing token" });
  try {
    const payload = jwt.verify(token, JWT_SECRET) as any;
    req.user = {
      id: payload.sub,
      email: payload.email,
      name: payload.name,
      avatarUrl: payload.avatarUrl,
    };
    next();
  } catch (e) {
    res.status(401).json({ error: "Invalid token" });
  }
};

export const meHandler: RequestHandler = (req, res) => {
  if (!req.user) return res.status(401).json({ error: "Unauthorized" });
  res.json(req.user);
};
